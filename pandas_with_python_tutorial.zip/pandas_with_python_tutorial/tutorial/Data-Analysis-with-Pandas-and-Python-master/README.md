# Data Analysis with Pandas and Python
by Boris Paskhaver

Link to course - https://www.udemy.com/data-analysis-with-pandas/
