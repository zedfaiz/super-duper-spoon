# Data-Science-Competitions
Goal of this repo is to provide solutions of all Data Science Competitions.
