#### Extraction of product attribute values
* 1st Place Solution ([Explanation](https://magicdata.eu/text-mining-machine-learning-detecting-skus/))

#### PKPD Modeling: Predict Exacerbation in patients with COPD
* 3rd Place Solution ([Explanation](https://mlwave.com/how-we-won-3rd-prize-in-crowdanalytix-copd-competition/))

#### Identifying Superheroes from product images
* 34th Place Solution ([code](https://github.com/skyprince999/Identify-Superheroes))
* Another Solution: [code](https://github.com/kanashov/Identifying-Superheroes-from-Product-Images)
* Another Solution: [code](https://github.com/lwkuant/Side_Project_Identifying_Superheroes)

