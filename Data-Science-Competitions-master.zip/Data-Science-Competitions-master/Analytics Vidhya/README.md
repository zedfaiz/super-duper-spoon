

#### Innoplexus Online Hiring Hackathon: Sentiment Analysis
* 14th Place Solution ([code](https://github.com/pawangeek/Ccmps/tree/master/innoplexus))
* 25th Place Solution ([code](https://github.com/rajat5ranjan/AV-Innoplexus-Online-Hiring-Hackathon-Sentiment-Analysis))
* 27th Place Solution ([code](https://github.com/Laxminarayen/Innoplex_Hackathon))
* 29th Place Solution ([code](https://github.com/chetanambi/Innoplexus-Online-Hiring-Hackathon-Sentiment-Analysis))

#### Genpact Machine Learning Hackathon
* 13th Place Solution ([code](https://github.com/rajat-1994/AV-Genpact-Hackathon))
* 32th Place Solution ([code](https://datahack-prod.s3.amazonaws.com/submissions/genpact-machine-learning-hackathon/440_505172_cf_baseline.ipynb))

#### Game of Deep Learning: Computer Vision Hackathon
* 1st Place Solution ([code](https://github.com/narensahu13/AV-Game-of-Deep-Learning))
* 2nd Place Solution ([code](https://github.com/salilmishra23/AnalyticsVidhya_GameOfDeepLearning))
* 3rd Place Solution ([code](https://www.kaggle.com/tezdhar/avships-densenet-v3))
* 5th Place Solution ([Explanation](https://docs.google.com/document/d/1ULIxyYW2b1zjoYolHI_rgneW8xkw3fVODw6fjqp9VXc/edit#heading=h.u1tdm64ah919))([code](https://github.com/xbassi/game_of_deep_learning))

#### Capillary Machine Learning Hackathon
* 4th Place Solution ([code](https://drive.google.com/file/d/1T2dGWdyCy7gCm5bPbKeZzpmBhKOdlLdx/view?usp=drive_open))
* 12th Place Solution ([code](https://datahack-prod.s3.amazonaws.com/submissions/capillary-machine-learning-hackathon/443_624878_cf_code_eJkEZMW.py))
* 13th Place Solution ([code](https://datahack-prod.s3.amazonaws.com/submissions/capillary-machine-learning-hackathon/443_622728_cf_current_best_y1yhRmZ.py))
