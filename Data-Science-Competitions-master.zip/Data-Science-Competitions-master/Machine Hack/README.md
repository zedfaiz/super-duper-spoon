#### Predicting The Costs Of Used Cars - Hackathon By Imarticus Learning
* 5th Place Solution ([code](https://github.com/chetanambi/Predicting-The-Costs-Of-Used-Cars-Hackathon-By-Imarticus-Learning))
* 11th Place Solution ([Explanation & code](https://www.kaggle.com/rajatranjan/fork-of-mh-predict-cost-of-used-cars-hackathon))

#### Predict A Doctor's Consultation Fee Hackathon
* 3rd Place Solution ([code](https://github.com/chetanambi/Predict-A-Doctors-Consultation-Fee-Hackathon))
* 8th Place Solution ([Explanation & code](https://www.kaggle.com/rajatranjan/predict-consultation-fee-doc-machinehack-re))

#### Predict The Flight Ticket Price Hackathon
* 3rd Place Solution  ([code](https://github.com/chetanambi/Predict-The-Flight-Ticket-Price-Hackathon))
* 11th Place Solution ([Explanation & code](https://www.kaggle.com/rajatranjan/predict-flight-tickets-machine-hack1))

#### Predicting Restaurant Food Cost Hackathon
* 5th Place Solution ([code](https://www.kaggle.com/rajatranjan/machinehack-predict-food-prices))
* 7th Place Solution ([code](https://github.com/chetanambi/Predicting-Restaurant-Food-Cost-Hackathon))

